// main/static/main/js/main.js

document.addEventListener('DOMContentLoaded', function () {
    // Toggle slot availability in the admin dashboard
    const availabilityToggles = document.querySelectorAll('.toggle-availability');
    availabilityToggles.forEach(toggle => {
        toggle.addEventListener('click', function (e) {
            const slotId = this.dataset.slotId;
            const isAvailable = this.checked;

            fetch(`/admin/toggle-availability/${slotId}/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: JSON.stringify({ is_available: isAvailable })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Slot availability updated successfully!');
                } else {
                    alert('Failed to update slot availability.');
                }
            })
            .catch(error => console.error('Error:', error));
        });
    });

    // Function to get CSRF token
    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                // Check for the cookie we're interested in
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }

    // Booking success confirmation
    const bookingSuccessMessage = document.querySelector('.booking-success');
    if (bookingSuccessMessage) {
        setTimeout(() => {
            bookingSuccessMessage.style.display = 'none';
        }, 5000); // Hide message after 5 seconds
    }

    // Modal functionality for confirmation before booking
    const bookButtons = document.querySelectorAll('.slot.available a');
    bookButtons.forEach(button => {
        button.addEventListener('click', function (e) {
            e.preventDefault();
            const confirmation = confirm('Are you sure you want to book this slot?');
            if (confirmation) {
                window.location.href = this.href; // Proceed to book
            }
        });
    });
});
