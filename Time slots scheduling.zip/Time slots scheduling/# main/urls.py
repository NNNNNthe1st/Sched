# main/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('generate_slots/', views.generate_slots, name='generate_slots'),
    path('view_slots/', views.view_slots, name='view_slots'),
    path('book_slot/<int:slot_id>/', views.book_slot, name='book_slot'),
    path('toggle_slot_availability/<int:slot_id>/', views.toggle_slot_availability, name='toggle_slot_availability'),
    path('admin_dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin_book_slot/<int:slot_id>/<int:user_id>/', views.admin_book_slot, name='admin_book_slot'),
]
