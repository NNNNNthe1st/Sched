# main/views.py

from django.shortcuts import render, redirect
from .models import TimeSlot, Booking
from .forms import BookingForm
from django.contrib.auth.decorators import login_required

@login_required
def schedule_view(request):
    slots = TimeSlot.objects.filter(is_available=True).order_by('day', 'start_time')
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.user = request.user  # Set the user who booked
            booking.save()
            # Mark the slot as unavailable
            slot = booking.time_slot
            slot.is_available = False
            slot.save()
            return redirect('booking_success')
    else:
        form = BookingForm()
    
    return render(request, 'main/schedule.html', {'slots': slots, 'form': form})

@login_required
def booking_success(request):
    return render(request, 'main/booking_success.html')
