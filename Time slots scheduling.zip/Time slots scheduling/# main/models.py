# main/models.py

from django.db import models
from django.utils import timezone
from django.core.mail import send_mail
from django.conf import settings
from datetime import timedelta, datetime

class TimeSlot(models.Model):
    day = models.DateField()  # Date of the slot
    start_time = models.TimeField()  # Start time of the slot
    end_time = models.TimeField()  # End time of the slot
    is_available = models.BooleanField(default=True)  # Slot availability
    booked_by = models.ForeignKey('auth.User', on_delete=models.SET_NULL, null=True, blank=True)  # Booking user

    class Meta:
        unique_together = ['day', 'start_time']

    def __str__(self):
        return f"{self.day} {self.start_time} - {self.end_time}"

    def book_slot(self, user):
        """ Book the slot for a user and send email confirmation. """
        self.booked_by = user
        self.is_available = False
        self.save()
        self.send_confirmation_email(user)

    def send_confirmation_email(self, user):
        """ Send email to user and customer service. """
        send_mail(
            subject="Booking Confirmation",
            message=f"Your booking for {self.day} from {self.start_time} to {self.end_time} has been confirmed.",
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[user.email, settings.CUSTOMER_SERVICE_EMAIL],
        )
