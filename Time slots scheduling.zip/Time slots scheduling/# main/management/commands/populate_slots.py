from django.core.management.base import BaseCommand
from main.models import TimeSlot
from datetime import datetime, timedelta, time
from django.utils import timezone

class Command(BaseCommand):
    help = 'Populate time slots for scheduling lessons'

    def handle(self, *args, **kwargs):
        current_date = timezone.now().date()
        end_date = current_date + timedelta(weeks=2)

        # Clear existing slots (optional)
        TimeSlot.objects.all().delete()

        start_time = time(7, 0)  # 7:00 AM
        end_time = time(22, 0)  # 10:00 PM
        lesson_duration = timedelta(minutes=40)
        break_duration = timedelta(minutes=10)

        for single_date in (current_date + timedelta(days=n) for n in range((end_date - current_date).days + 1)):
            current_slot_time = datetime.combine(single_date, start_time)
            while current_slot_time.time() < end_time:
                slot_end_time = (current_slot_time + lesson_duration).time()
                TimeSlot.objects.get_or_create(
                    day=single_date,
                    start_time=current_slot_time.time(),
                    end_time=slot_end_time,
                    is_available=True
                )
                current_slot_time += lesson_duration + break_duration

        self.stdout.write(self.style.SUCCESS('Successfully populated time slots'))
