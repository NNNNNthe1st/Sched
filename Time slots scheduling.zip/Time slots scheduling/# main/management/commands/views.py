# main/views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.contrib.auth.decorators import login_required, user_passes_test
from django.http import JsonResponse
from .models import TimeSlot
from datetime import timedelta, time, datetime

def generate_slots(request):
    """ Populate slots from today up to two weeks in advance. """
    today = timezone.now().date()
    for day in range(14):  # Two weeks
        current_day = today + timedelta(days=day)
        start_time = time(7, 0)  # Start at 7:00 AM
        while start_time < time(22, 0):  # End at 10:00 PM
            end_time = (datetime.combine(current_day, start_time) + timedelta(minutes=40)).time()
            TimeSlot.objects.get_or_create(day=current_day, start_time=start_time, end_time=end_time)
            start_time = (datetime.combine(current_day, start_time) + timedelta(minutes=50)).time()  # 10-min interval
    return JsonResponse({'status': 'Slots generated successfully'})

@login_required
def view_slots(request):
    """ View all available slots. """
    slots = TimeSlot.objects.filter(day__gte=timezone.now().date()).order_by('day', 'start_time')
    return render(request, 'main/view_slots.html', {'slots': slots})

@login_required
def book_slot(request, slot_id):
    """ Book a specific slot by ID. """
    slot = get_object_or_404(TimeSlot, id=slot_id, is_available=True)
    slot.book_slot(request.user)
    return redirect('view_slots')

@user_passes_test(lambda u: u.is_staff)
def toggle_slot_availability(request, slot_id):
    """ Admin toggles slot availability. """
    slot = get_object_or_404(TimeSlot, id=slot_id)
    slot.is_available = not slot.is_available
    slot.save()
    return redirect('view_slots')

@user_passes_test(lambda u: u.is_staff)
def admin_book_slot(request, slot_id, user_id):
    """ Admin books a slot on behalf of a student. """
    user = get_object_or_404(User, id=user_id)
    slot = get_object_or_404(TimeSlot, id=slot_id, is_available=True)
    slot.book_slot(user)
    return redirect('admin_dashboard')
